# ADMIN_settings.py

# -*- coding:utf-8 -*-
"""
Ctyun cloudaio admin project setting.
"""

AUTO_APPROVE_CUSTOMER_ORDER = True

VMS_SERVICE_HOST = ''
VMS_SERVICE_PORT = ''
VMS_SERVICE_DB_NAME = ''
VMS_SERVICE_DB_USERNAME = ''
VMS_SERVICE_DB_PASSWORD = ''

EMAIL_ADMIN_ADDR = ''
EMAIL_ADMIN_HOST = ''
EMAIL_ADMIN_PORT = 0
EMAIL_ADMIN_USER = ''
EMAIL_ADMIN_PASSWORD = ''

LOGIN_FROM_CAS = False
LOGOUT_REDIRECT_URL = '/'
# uam settings, is valid only when LOGIN_FROM_CAS is true
CAS_SERVER_URL = 'http://10.0.38.147:18080/cas/'
CAS_REDIRECT_URL = '/'
CAS_VERSION = '3'

CAS_SERVICE_URL = 'http://10.0.38.147:16080'

# ctyun user info interface
USEE_INFO_URL = "http://192.168.13.122:81/account/QueryAccountInfo"
CS_CONSOLE_PROXY_HOST = "172.18.143.13"
CS_CONSOLE_PROXY_PORT = "8020"

WORK_ORDER_SYSTEM_URL = "http://10.1.34.43:12080"

# monitor
PARSE_HOST = '172.18.210.100:10000'
PARSE_REST_APIKEY = 'ctcloud'
PARSE_APPLICATION_ID = 'myAppId'
PARSE_USERNAME = 'appUser'
PARSE_PASSWORD = 'ctcApp123'

# redis settings for openapi
REDIS_OPENAPI_DB = 3
REDIS_HOST = '10.1.34.43'
REDIS_PORT = 6379

# RabbitMQ
RABBITMQ_HOST = '10.1.34.43'
RABBITMQ_PORT = 5672
RABBITMQ_VHOST = 'ecscloud'
RABBITMQ_USERNAME = 'ecscloud'
RABBITMQ_PASSWORD = 'ecscloud'
RABBITMQ_ROUTINGKEY_PREFIX = 'VMS1'
# RABBITMQ_ROUTINGKEY_PREFIX = 'omsvms'
LOG_DIR = "/var/log/"

DATABASES = {
    'default': {
        'NAME': 'yj_admin',
        'ENGINE': 'django.db.backends.mysql',  # or use mysql.connector.django
        'USER': 'test',
        'PASSWORD': 'test123',
        'HOST': '10.1.34.43',
        'PORT': '3306',
    },
    'cloudaio': {
        'NAME': 'yj_manage',
        'ENGINE': 'django.db.backends.mysql',  # or use mysql.connector.django
        'USER': 'test',
        'PASSWORD': 'test123',
        'HOST': '10.1.34.43',
        'PORT': '3306',
    },
}

import os

apps = ('cloudaio',)

ROOT_PATH = os.path.dirname(os.path.abspath(__file__))
ROOT_URLCONF = 'cloudaio.urls'
WEB_ROOT = "/aio/"
STATIC_ROOT = os.path.abspath(os.path.join(ROOT_PATH, 'static'))
STATIC_URL = WEB_ROOT + 'static/'

INSTALLED_APPS = (
    'cloudaio',
    'cloudmanage',
    'openapi',
    'cloudoms',

    'django.contrib.contenttypes',
    'django.contrib.auth',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    # 'crispy_forms',

    'rest_framework',
    'django_cas_ng',
    # 'django_cas_ng',
    # 'django_celery_results',
)

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [ROOT_PATH + "/templates"],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.i18n',
                'django.template.context_processors.request',
                'django.template.context_processors.media',
                'django.template.context_processors.static',
                'django.contrib.messages.context_processors.messages',
                'django.contrib.auth.context_processors.auth',
            ],
        },
    },
]

MIDDLEWARE_CLASSES = (
    # 'django.middleware.cache.UpdateCacheMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    # 'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.auth.middleware.SessionAuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    # 'django.middleware.cache.FetchFromCacheMiddleware',
    # 'django_cas_ng.middleware.CASMiddleware',
    'cloudoms.middlewares.base.LoggingMiddleware'
)

LOCALE_PATHS = (
    os.path.join(ROOT_PATH, 'locale'),
)

AUTHENTICATION_BACKENDS = ('django.contrib.auth.backends.ModelBackend',)

if LOGIN_FROM_CAS:
    CAS_BACKEND = ('cloudaio.backends.UAMCASBackend',)
    AUTHENTICATION_BACKENDS = CAS_BACKEND + AUTHENTICATION_BACKENDS

PASSWORD_CRYPT_KEY1 = '6aNWeRP8ziXqpTQG'
PASSWORD_CRYPT_KEY2 = 'zidXj5E7bnHy63is'

# cloudstack api config
CLOUDSTACK_API_DEBUGGING = False
CLOUDSTACK_API_VERBOSE = True

AUTH_USER_MODEL = 'cloudaio.SysUser'

REST_FRAMEWORK = {
    'DEFAULT_PERMISSION_CLASSES': (
        'rest_framework.permissions.IsAdminUser',
    ),
    'DEFAULT_AUTHENTICATION_CLASSES': (
        # 'rest_framework.authentication.TokenAuthentication',
        'openapi.expiringtoken.ExpiringTokenAuthentication',
    ),
    'PAGINATE_BY': 10
}

DATABASE_ROUTERS = ['cloudaio.utils.db_router.DBRouter', ]

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'standard': {
            'format': '[%(levelname)s %(filename)s %(lineno)s %(asctime)s] %(message)s'
        },
    },
    'filters': {
    },
    'handlers': {
        'file': {
            'level': 'DEBUG',
            'class': 'logging.handlers.RotatingFileHandler',
            'maxBytes': 1024 * 1024 * 5,
            'backupCount': 5,
            'filename': '%s/cloudaio.log' % LOG_DIR,
        },
        'access': {
            'level': 'DEBUG',
            'class': 'logging.handlers.RotatingFileHandler',
            'maxBytes': 1024 * 1024 * 5,
            'backupCount': 5,
            'filename': '%s/cloudaio-access.log' % LOG_DIR,
            'formatter': 'standard',
        },
    },
    'loggers': {
        'django.request': {
            'handlers': ['file'],
            'level': 'DEBUG',
            'propagate': True,
        },
        'access_log': {
            'handlers': ['access'],
            'level': 'DEBUG',
            'propagate': True,
        },
        'cloudaio': {
            'handlers': ['access'],
            'level': 'DEBUG',
            'propagate': True
        },
        'cloudoms': {
            'handlers': ['access'],
            'level': 'DEBUG',
            'propagate': True
        }
    },
}

from cloudaio.settings import REST_FRAMEWORK

API_TOKEN_EXPIRE_DAYS = 7

SECURE_REQUIRED_PATHS = (
    '/aio/api/',
)
HTTPS_SUPPORT = True
CS_SESSION_CACHE = ['127.0.0.1:11211']

# celery
BROKER_URL = 'redis://%s:%s/1' % (REDIS_HOST, REDIS_PORT)
CELERY_BROKER_URL = BROKER_URL
CELERY_RESULT_BACKEND = 'redis://%s:%s/1' % (REDIS_HOST, REDIS_PORT)
CELERY_TIMEZONE = 'UTC'
CELERY_IMPORTS = ('tasks', 'cloudoms.tasks',)

from openapi.celeryd import CELERYBEAT_SCHEDULE

SECRET_KEY = "YFUrfeflJNlh66DVFBTwZngp5P2o1WUjR9d2GGRHF8rhU7utfpy1PI7NwhuVTJho"
ALLOWED_HOSTS = ['*', ]
DEBUG = True

# LOGGING_CONFIG = None

USE_TZ = True

import logging

try:
    from local.local_settings import *  # noqa
except ImportError as e:
    logging.error(e)
    logging.warning("No local_settings file found.")
# console zabbix api access key, secret key
CLOUDAIO_ADMIN_API_AK = '1c00d81ef5a211e7b82f186590d96509'
CLOUDAIO_ADMIN_API_SK = 'ddb625423707f651ee45c0d8f1ecb1a56ba9118c'

LANGUAGE_CODE = 'zh_CN'
USE_I18N = True
# -*- coding:utf-8-*-