#!/usr/bin/env bash
yum install expect -y

#!/bin/expect
spawn python manage.py createsuperuser
expect 'Username:'
send 'test'
expect 'Email:'
send 'test@test.com'
expect 'Password:'
send 'test'
expect 'Password (again):'
send 'test'
exit 0