# -*- coding: utf-8 -*-
import os

# RabbitMQ
RABBIT_RECEIVE_HOST = os.environ.get("RABBIT_RECEIVE_HOST")
RABBIT_RECEIVE_VHOST = os.environ.get("RABBIT_RECEIVE_VHOST")
RABBIT_RECEIVE_USERNAME = os.environ.get("RABBIT_RECEIVE_USERNAME")
RABBIT_RECEIVE_PASSWORD = os.environ.get("RABBIT_RECEIVE_PASSWORD")
RABBIT_RECEIVE_PORT = 5672
RABBIT_RECEIVE_EXCHANGE_NAME = os.environ.get("RABBIT_RECEIVE_EXCHANGE_NAME")
RABBIT_RECEIVE_EXCHANGE_TYPE = os.environ.get("RABBIT_RECEIVE_EXCHANGE_TYPE")

RABBIT_SEND_HOST = os.environ.get("RABBIT_SEND_HOST")
RABBIT_SEND_VHOST = os.environ.get("RABBIT_SEND_VHOST")
RABBIT_SEND_USERNAME = os.environ.get("RABBIT_SEND_USERNAME")
RABBIT_SEND_PASSWORD = os.environ.get("RABBIT_SEND_PASSWORD")
RABBIT_SEND_PORT = 5672
RABBIT_SEND_EXCHANGE_NAME = os.environ.get("RABBIT_SEND_EXCHANGE_NAME")
RABBIT_SEND_EXCHANGE_TYPE = os.environ.get("RABBIT_SEND_EXCHANGE_TYPE")
RABBIT_SEND_ROUTING_KEY = os.environ.get("RABBIT_SEND_ROUTING_KEY")

API_ADDRESS = os.environ.get("API_ADDRESS")
API_PORT = int(os.environ.get("API_PORT"))

RABBIT_OTHER_HOST = os.environ.get("RABBIT_OTHER_HOST")
RABBIT_OTHER_VHOST = os.environ.get("RABBIT_OTHER_VHOST")
RABBIT_OTHER_USERNAME = os.environ.get("RABBIT_OTHER_USERNAME")
RABBIT_OTHER_PASSWORD = os.environ.get("RABBIT_OTHER_PASSWORD")
RABBIT_OTHER_PORT = int(os.environ.get("RABBIT_OTHER_PORT"))
RABBIT_OTHER_EXCHANGE_NAME = os.environ.get("RABBIT_OTHER_EXCHANGE_NAME")
RABBIT_OTHER_EXCHANGE_TYPE = os.environ.get("RABBIT_OTHER_EXCHANGE_TYPE")
RABBIT_OTHER_ROUTING_KEY_LIST =os.environ.get("RABBIT_OTHER_VHOST")


ADMIN_API_HANDLE = '/aio/oms/restapi/msg/handle/'
ADMIN_API_RESOURCE = '/aio/oms/restapi/msg/resource/'
ADMIN_BASE_URL = '192.168.14.123:8081'
CH_ORDER_KEY = 'znet.apiproxy.workOrderResourceAMQP'
PAAS_ORDER_KEY = 'paas.workOrderResourceAMQP'
ECS_RESOURCE_KEY = 'ovms.noticeResInstanceAMQP'
ECS_ORDER_KEY = 'ovms.workOrderResourceAMQP'
PAAS_RESOURCE_KEY = 'paas.noticeResInstanceAMQP'


MQ_KEY_API_MAPPING = '[ECS_ORDER_KEY],[ADMIN_BASE_URL][ADMIN_API_HANDLE];[PAAS_ORDER_KEY],[ADMIN_BASE_URL][ADMIN_API_HANDLE];[ECS_RESOURCE_KEY],[ADMIN_BASE_URL][ADMIN_API_RESOURCE];[PAAS_RESOURCE_KEY],[ADMIN_BASE_URL][ADMIN_API_RESOURCE];[CH_ORDER_KEY],[ADMIN_BASE_URL][ADMIN_API_HANDLE]'


def get_env(k, default=False):
    if not os.environ.get(k):
        return default
    else:
        if str(os.environ.get(k)).lower() in ["1", "true"]:
            return True
        else:
            return False


EXCHANGE_DURABLE = get_env("EXCHANGE_DURABLE", default=True)
EXCHANGE_AUTO_DELETE = get_env("EXCHANGE_AUTO_DELETE", default=True)
QUEUE_DURABLE = get_env("QUEUE_DURABLE", default=True)
QUEUE_AUTO_DELETE = get_env("QUEUE_AUTO_DELETE", default=True)
QUEUE_EXCLUSIVE = get_env("QUEUE_EXCLUSIVE", default=True)

OTHER_ROUTING_KEY_LIST = os.environ.get("OTHER_ROUTING_KEY_LIST") or RABBIT_OTHER_ROUTING_KEY_LIST
KEY_API_MAPPING = os.environ.get("KEY_API_MAPPING") or MQ_KEY_API_MAPPING

WORKORDER_RABBITMQ_PROP = {
    "rabbitmq.host": os.environ.get("RABBIT_RECEIVE_HOST") or RABBIT_RECEIVE_HOST,
    "rabbitmq.vhost": os.environ.get("RABBIT_RECEIVE_VHOST") or RABBIT_RECEIVE_VHOST,
    "rabbitmq.username": os.environ.get("RABBIT_RECEIVE_USERNAME") or RABBIT_RECEIVE_USERNAME,
    "rabbitmq.password": os.environ.get("RABBIT_RECEIVE_PASSWORD") or RABBIT_RECEIVE_PASSWORD,
    "rabbitmq.port": int(os.environ.get("RABBIT_RECEIVE_PORT")) if os.environ.get(
        "RABBIT_RECEIVE_PORT") else RABBIT_RECEIVE_PORT,
    "rabbitmq.exchange_name": os.environ.get("RABBIT_RECEIVE_EXCHANGE_NAME") or RABBIT_RECEIVE_EXCHANGE_NAME,
    "rabbitmq.exchange_type": os.environ.get("RABBIT_RECEIVE_EXCHANGE_TYPE") or RABBIT_RECEIVE_EXCHANGE_TYPE,
    "rabbitmq.exchange_durable": True,
    "rabbitmq.exchange_auto_delete": False,
    "rabbitmq.queue_durable": False,
    "rabbitmq.queue_auto_delete": False,
    "rabbitmq.queue_exclusive": False,
    "rabbitmq.prefetch_count": 32
}

WORKORDER_RABBITMQ_REPORT = {
    "rabbitmq.host": os.environ.get("RABBIT_SEND_HOST") or RABBIT_SEND_HOST,
    "rabbitmq.vhost": os.environ.get("RABBIT_SEND_VHOST") or RABBIT_SEND_VHOST,
    "rabbitmq.username": os.environ.get("RABBIT_SEND_USERNAME") or RABBIT_SEND_USERNAME,
    "rabbitmq.password": os.environ.get("RABBIT_SEND_PASSWORD") or RABBIT_SEND_PASSWORD,
    "rabbitmq.port": int(os.environ.get("RABBIT_SEND_PORT")) if os.environ.get(
        "RABBIT_SEND_PORT") else RABBIT_SEND_PORT,
    "rabbitmq.exchange_name": os.environ.get("RABBIT_SEND_EXCHANGE_NAME") or RABBIT_SEND_EXCHANGE_NAME,
    "rabbitmq.exchange_type": os.environ.get("RABBIT_SEND_EXCHANGE_TYPE") or RABBIT_SEND_EXCHANGE_TYPE,
    "rabbitmq.exchange_durable": True,
    "rabbitmq.exchange_auto_delete": False,
    "rabbitmq.queue_durable": False,
    "rabbitmq.queue_auto_delete": False,
    "rabbitmq.queue_exclusive": False,
    "rabbitmq.routing_key": os.environ.get("RABBIT_SEND_ROUTING_KEY") or RABBIT_SEND_ROUTING_KEY,
    "rabbitmq.prefetch_count": 32
}

RABBIT_CUSTOM_SEND = {
    "rabbitmq.host": os.environ.get("RABBIT_CUSTOM_SEND_HOST") or os.environ.get(
        "RABBIT_SEND_HOST") or RABBIT_SEND_HOST,
    "rabbitmq.vhost": os.environ.get("RABBIT_CUSTOM_SEND_VHOST") or os.environ.get(
        "RABBIT_SEND_VHOST") or RABBIT_SEND_VHOST,
    "rabbitmq.username": os.environ.get("RABBIT_CUSTOM_SEND_USERNAME") or os.environ.get(
        "RABBIT_SEND_USERNAME") or RABBIT_SEND_USERNAME,
    "rabbitmq.password": os.environ.get("RABBIT_CUSTOM_SEND_PASSWORD") or os.environ.get(
        "RABBIT_SEND_PASSWORD") or RABBIT_SEND_PASSWORD,
    "rabbitmq.port": int(os.environ.get("RABBIT_CUSTOM_SEND_PORT")) if os.environ.get(
        "RABBIT_CUSTOM_SEND_PORT") else RABBIT_SEND_PORT,
    "rabbitmq.exchange_name": os.environ.get("RABBIT_CUSTOM_SEND_EXCHANGE_NAME") or os.environ.get(
        "RABBIT_SEND_EXCHANGE_NAME") or RABBIT_SEND_EXCHANGE_NAME,
    "rabbitmq.exchange_type": os.environ.get("RABBIT_CUSTOM_SEND_EXCHANGE_TYPE") or os.environ.get(
        "RABBIT_SEND_EXCHANGE_TYPE") or RABBIT_SEND_EXCHANGE_TYPE,
    "rabbitmq.exchange_durable": True,
    "rabbitmq.exchange_auto_delete": False,
    "rabbitmq.queue_durable": False,
    "rabbitmq.queue_auto_delete": False,
    "rabbitmq.queue_exclusive": False,
    "rabbitmq.prefetch_count": 32
}

RABBITMQ_OTHER = {
    "rabbitmq.host": os.environ.get("RABBIT_OTHER_HOST") or RABBIT_OTHER_HOST,
    "rabbitmq.vhost": os.environ.get("RABBIT_OTHER_VHOST") or RABBIT_OTHER_VHOST,
    "rabbitmq.username": os.environ.get("RABBIT_OTHER_USERNAME") or RABBIT_OTHER_USERNAME,
    "rabbitmq.password": os.environ.get("RABBIT_OTHER_PASSWORD") or RABBIT_OTHER_PASSWORD,
    "rabbitmq.port": int(os.environ.get("RABBIT_OTHER_PORT")) if os.environ.get(
        "RABBIT_OTHER_PORT") else RABBIT_OTHER_PORT,
    "rabbitmq.exchange_name": os.environ.get("RABBIT_OTHER_EXCHANGE_NAME") or RABBIT_OTHER_EXCHANGE_NAME,
    "rabbitmq.exchange_type": os.environ.get("RABBIT_OTHER_EXCHANGE_TYPE") or RABBIT_OTHER_EXCHANGE_TYPE,
    "rabbitmq.exchange_durable": EXCHANGE_DURABLE,
    "rabbitmq.exchange_auto_delete": EXCHANGE_AUTO_DELETE,
    "rabbitmq.queue_durable": QUEUE_DURABLE,
    "rabbitmq.queue_auto_delete": QUEUE_AUTO_DELETE,
    "rabbitmq.queue_exclusive": QUEUE_EXCLUSIVE,
    "rabbitmq.routing_key": "",
    "rabbitmq.prefetch_count": 32
}

api_address = os.environ.get('API_ADDRESS') or API_ADDRESS
api_port = int(os.environ.get('API_PORT')) if os.environ.get('API_PORT') else API_PORT

STATUS_OK = '1'

# Log
log_file_path = '/var/log/ecscloud/msghandler.log'