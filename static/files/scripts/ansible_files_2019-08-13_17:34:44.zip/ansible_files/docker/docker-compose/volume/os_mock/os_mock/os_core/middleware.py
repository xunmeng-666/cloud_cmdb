import logging
import time
from django.utils.deprecation import MiddlewareMixin

LOG = logging.getLogger(__name__)


class DisableCsrfCheck(MiddlewareMixin):
    def process_request(self, req):
        try:
            try:
                data = str(req.data)
                info = "requested_url is:{}, data:{}".format(str(req.get_full_path()), data)
            except:
                data = unicode(req.data)
                info = u"requested_url is:{}, data:{}".format(str(req.get_full_path()), data)
        except:
            info = "requested_url is:{}, data:{}".format(str(req.get_full_path()), "")

        LOG.info(info)
        attr = '_dont_enforce_csrf_checks'
        if not getattr(req, attr, False):
            setattr(req, attr, True)


# class TimeDelay(MiddlewareMixin):
#     def process_request(self, req):
#         time.sleep(10)

