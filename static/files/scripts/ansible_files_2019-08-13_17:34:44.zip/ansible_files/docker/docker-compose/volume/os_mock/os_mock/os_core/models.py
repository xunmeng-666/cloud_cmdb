# -*- coding: utf-8 -*-
import uuid
import json
from django.db import models


class BaseModel(models.Model):
    id = models.CharField(primary_key=True, max_length=128, default=uuid.uuid4)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    name = models.CharField(max_length=256, blank=True, null=True)

    def to_dict(self):
        opts = self._meta
        data = {}
        for f in opts.concrete_fields:
            data[f.name] = f.value_from_object(self)
        return data

    def __unicode__(self):
        return u"ID:%s NAME:%s CREATED_AT:%s" % (self.id, self.name, self.created_at)

    class Meta:
        abstract = True


class Project(BaseModel):
    @classmethod
    def admin_project(cls):
        admin = cls.objects.filter(name="admin").first()
        if admin:
            return admin
        else:
            return cls.objects.create(name="admin")

    def save(self, *args, **kwargs):
        super(Project, self).save(*args, **kwargs)

        if self.name != "admin":
            sc = SCGroup.create_default(self)
            SCGroupRule.create_default(sc)


class User(BaseModel):
    password = models.CharField(max_length=256, blank=True, null=True)
    email = models.CharField(max_length=256, blank=True, null=True)


class Role(BaseModel): pass


class ProjectUserRole(models.Model):
    project = models.ForeignKey(Project)
    user = models.ForeignKey(User)
    role = models.ForeignKey(Role)

    def to_dict(self):
        return {"project": self.project_id, "user": self.user_id, "role": self.role_id}


class ResourceBase(BaseModel):
    project = models.ForeignKey('os_core.Project')
    deleted_at = models.DateTimeField(blank=True, null=True)
    deleted = models.BooleanField(default=False)
    detail = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=64, blank=True, null=True)

    class Meta:
        abstract = True


class Image(ResourceBase):
    size = models.IntegerField(default=40)
    volume = models.ForeignKey('os_core.Volume', blank=True, null=True)
    public = models.BooleanField(default=False)

    def to_dict(self):
        result = super(Image, self).to_dict()
        result['size'] = self.size * 1024 * 1024 * 1024
        result["status"] = "active"
        result["os_type"] = "windows" if "win" in self.name.lower() else "linux"
        return result

    def save(self, *args, **kwargs):
        try:
            self.project
        except:
            self.project = Project.admin_project()
        super(Image, self).save(*args, **kwargs)


class Flavor(ResourceBase):
    ram = models.IntegerField()
    vcpus = models.IntegerField()

    def save(self, *args, **kwargs):
        try:
            self.project
        except:
            self.project = Project.admin_project()
        super(Flavor, self).save(*args, **kwargs)


class Network(ResourceBase):
    cidr = models.CharField(max_length=64)

    def to_dict(self):
        result = super(Network, self).to_dict()
        result['subnet_ids'] = list(self.subnet_set.values_list('id', flat=1))
        return result


class Subnet(ResourceBase):
    network = models.ForeignKey(Network)
    cidr = models.CharField(max_length=64)
    gateway_ip = models.CharField(max_length=64)

    def assign_fixed_ip(self):
        import random
        from netaddr import IPNetwork
        all_ips = [str(i) for i in IPNetwork(self.cidr)]
        used_ips = list(self.port_set.values_list('ip', flat=1))
        return random.choice(list(set(all_ips).difference(set(used_ips))))


class Floating(ResourceBase):
    ip = models.CharField(max_length=128)
    bandwidth = models.IntegerField(default=1)
    bound = models.BooleanField(default=False)
    bound_at = models.DateTimeField(blank=True, null=True)
    floating_network_id = models.CharField(max_length=128, blank=True, null=True)
    qos_policy_id = models.CharField(max_length=128, blank=True, null=True)
    fixed_ip_address = models.CharField(max_length=128, blank=True, null=True) # instance内网IP，绑定云主机后才会有
    floating_ip_address = models.CharField(max_length=128, blank=True, null=True)

    def to_dict(self):
        result = super(Floating, self).to_dict()
        result["floating_ip_address"] = self.ip
        result["name"] = self.ip
        return result


class SCGroup(ResourceBase):
    @classmethod
    def create_default(cls, project):
        sc = cls.objects.create(project=project, name="default")
        sc.detail = json.dumps({"default_rule": sc.default_rules()})
        sc.save()
        return sc

    def default_rules(self):
        return {u'remote_group_id': None, u'direction': u'egress', u'protocol': None, u'description': None, u'tags': [],
                u'ethertype': u'IPv4', u'port_range_max': None, u'updated_at': self.updated_at.isoformat(),
                u'security_group_id': str(self.pk),
                u'tenant_id': str(self.project_id), u'port_range_min': None, u'revision_number': 0,
                u'remote_ip_prefix': None, u'id': str(uuid.uuid4()),
                u'project_id': str(self.project_id), u'created_at': self.created_at.isoformat()}

    def to_dict(self):
        result = super(SCGroup, self).to_dict()
        rules = [self.default_rules()]
        rules.extend([i.to_dict() for i in self.scgrouprule_set.all()])
        result['security_group_rules'] = rules
        return result


class SCGroupRule(ResourceBase):
    sc_group = models.ForeignKey('os_core.SCGroup')

    @classmethod
    def create_default(cls, sc):
        return cls.objects.create(project=sc.project, sc_group=sc, name="default",
                                  id=json.loads(sc.detail)["default_rule"]["id"],
                                  detail=json.dumps(json.loads(sc.detail)["default_rule"]))

    def to_dict(self):
        result = super(SCGroupRule, self).to_dict()
        rule_detail = dict(result, **json.loads(self.detail))
        common_detail = {u'remote_group_id': None, u'direction': u'egress', u'protocol': None, u'description': None,
                         u'tags': [], u'ethertype': u'IPv4', u'port_range_max': None,
                         u'security_group_id': str(self.sc_group_id), u'tenant_id': str(self.project_id),
                         u'port_range_min': None,
                         u'revision_number': 0, u'remote_ip_prefix': None}
        return dict(common_detail, **rule_detail)




class Instance(ResourceBase):
    subnet = models.ForeignKey(Subnet)
    network = models.ForeignKey(Network)
    image = models.ForeignKey(Image)
    flavor = models.ForeignKey(Flavor)
    security_group = models.ForeignKey(SCGroup)
    floating = models.OneToOneField(Floating, blank=True, null=True)
    fixed_ip = models.CharField(max_length=128)
    public_ip = models.CharField(max_length=128, blank=True, null=True)
    availability_zone = models.CharField(max_length=128, default='public')
    addresses = models.TextField(blank=True, null=True, default=json.dumps({}))
    addresses_updated = models.BooleanField(default=False)

    def to_dict(self):
        result = super(Instance, self).to_dict()
        result["attached_volumes"] = [{"id": i.pk} for i in self.volume_set.all()]
        result["flavor"] = {"id": self.flavor_id}
        result["image"] = {"id": self.image_id}
        try:
            _addresses = json.loads(self.addresses)
        except:
            _addresses = []
        if self.addresses_updated and _addresses:
            addresses = json.loads(self.addresses)
        else:
            if self.floating_id:
                addresses = {
                    self.network.name: [{"addr": self.floating.ip, "OS-EXT-IPS:type": "floating",
                                         'OS-EXT-IPS-MAC:mac_addr': "fake"}] + [
                                           {"addr": i.ip, "OS-EXT-IPS:type": "fixed", 'OS-EXT-IPS-MAC:mac_addr': "fake"}
                                           for i in
                                           self.port_set.all()]}
            else:
                addresses = {
                    self.network.name: [{"addr": i.ip, "OS-EXT-IPS:type": "fixed", 'OS-EXT-IPS-MAC:mac_addr': "fake"}
                                        for i in
                                        self.port_set.all()]}
            self.addresses = json.dumps(addresses)
            self.addresses_updated = True
            self.save()
        if not addresses.get(self.network.name):
            addresses = {
                self.network.name: [
                    {"addr": "172.31.0.1", "OS-EXT-IPS:type": "fixed", 'OS-EXT-IPS-MAC:mac_addr': "fake"}]}
        result["addresses"] = addresses
        return result



class Router(ResourceBase):
    pass


class Port(ResourceBase):
    network = models.ForeignKey(Network)
    subnet = models.ForeignKey(Subnet)
    router = models.ForeignKey(Router, blank=True, null=True)
    instance = models.ForeignKey(Instance, blank=True, null=True)
    ip = models.CharField(max_length=128)


class Volume(ResourceBase):
    size = models.IntegerField(default=40)
    volume_type = models.CharField(max_length=64, default=u"SATA")
    instance = models.ForeignKey(Instance, blank=True, null=True)
    is_bootable = models.BooleanField(default=False)
    attached_at = models.DateTimeField(blank=True, null=True)

    def to_dict(self):
        result = super(Volume, self).to_dict()
        result["size"] = self.size
        if self.instance_id:
            result["attachments"] = [{"id": self.instance_id, "device": "/dev/sda"}]
        else:
            result["attachments"] = []
        return result
