
ps -ef |grep uwsgi|grep -v grep|cut -c 9-15 |xargs kill -9
uwsgi --ini uwsgi.ini
sleep 2
ps -ef
