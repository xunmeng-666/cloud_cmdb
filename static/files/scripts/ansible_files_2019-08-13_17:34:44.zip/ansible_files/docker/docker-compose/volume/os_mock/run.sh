#!/usr/bin/env bash


docker run -itd --privileged --name os_mock \
-p 8775:8000 \
--env-file=mock.env \
-v /etc/localtime:/etc/localtime:ro \
-v /sys/fs/cgroup:/sys/fs/cgroup:ro os_mock "/usr/sbin/init"


docker exec os_mock bash -c "cd /var/www/os_mock; /bin/bash ./update_database.sh"
docker exec os_mock bash -c "cd /var/www/os_mock; /bin/bash ./res.sh"
