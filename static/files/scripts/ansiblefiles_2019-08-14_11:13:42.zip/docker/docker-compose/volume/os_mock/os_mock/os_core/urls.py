from rest_framework.routers import DefaultRouter

from . import views

router = DefaultRouter()
router.register(r'identity', views.IdentityViewSet, base_name='identity')
router.register(r'compute', views.ComputeViewSet, base_name='compute')
router.register(r'network', views.NetworkViewSet, base_name='network')
router.register(r'image', views.ImageViewSet, base_name='image')
router.register(r'block_store', views.BlockStoreViewSet, base_name='block_store')
urlpatterns = router.urls
