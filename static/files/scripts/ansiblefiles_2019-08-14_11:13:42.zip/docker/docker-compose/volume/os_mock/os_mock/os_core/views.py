# -*- coding: utf-8 -*-
from django.utils import timezone
from rest_framework import viewsets
from django.db.models import Q
from rest_framework.decorators import action
from rest_framework.response import Response

from .models import *

post_action = action(detail=False, methods=['post'])


def success_response(data=None):
    if not data:
        data = []
    return Response({"data": data, "status_code": 1})


def error_response(msg="error", data=None):
    return Response({"data": data, "status_code": 0, "msg": msg})


class ReqParser(object):
    @staticmethod
    def req_parser(req):
        try:
            req = req.data
            rc = json.loads(req['rc'])
            project_id = rc.get("project_id")
            if str(rc.get("project_name")).lower() == "admin":
                project_id = "admin"
            elif not project_id:
                project_id = Project.objects.get(name=rc.get("project_name")).pk
            args = json.loads(req['args'])
            kwargs = json.loads(req['kwargs'])
            return project_id, args, kwargs
        except Exception as e:
            print e
            return "", [], {}

    @staticmethod
    def first_or_none(args):
        try:
            return args[0]
        except IndexError:
            return None


class IdentityViewSet(viewsets.ViewSet, ReqParser):
    """
    identity
    projects = self.identity.projects(name=project_name)
    project = self.identity.create_project(name=name, description=description)
    users = self.identity.users(name=user_name)
    user = self.identity.create_user(name=keystone_user, email=keystone_email, password=keystone_pwd)
    roles = self.conn.identity.roles()

    """

    @post_action
    def projects(self, request):
        project_id, args, kwargs = self.req_parser(request)
        name = kwargs.get("name") or self.first_or_none(args)
        if name:
            qs = Project.objects.filter(name=name)
        else:
            qs = Project.objects.all()
        data = [i.to_dict() for i in qs]
        return success_response(data)

    @post_action
    def create_project(self, request):
        project_id, args, kwargs = self.req_parser(request)
        name = kwargs.get("name")
        if name:
            project = Project.objects.create(name=name)
            return success_response(project.to_dict())
        else:
            return success_response({})

    @post_action
    def get_project(self, request):
        project_id, args, kwargs = self.req_parser(request)

        try:
            q_project_id = args[0]
            project = Project.objects.get(pk=q_project_id)
            return success_response(project.to_dict())
        except Exception as e:
            print e
            return success_response({})

    @post_action
    def users(self, request):
        project_id, args, kwargs = self.req_parser(request)
        name = kwargs.get("name") or self.first_or_none(args)
        if name:
            qs = User.objects.filter(name=name)
        else:
            qs = User.objects.all()
        data = [i.to_dict() for i in qs]
        return success_response(data)

    @post_action
    def create_user(self, request):
        project_id, args, kwargs = self.req_parser(request)
        name = kwargs.get("name")
        if name:
            obj = User.objects.create(name=name, email=kwargs.get("email"), password=kwargs.get("password"))
            return success_response(obj.to_dict())
        else:
            return success_response({})

    @post_action
    def get_user(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            q_pk = args[0]
            user = User.objects.get(pk=q_pk)
            return success_response(user.to_dict())
        except Exception as e:
            print e
            return success_response({})

    @post_action
    def roles(self, request):
        try:
            Role.objects.get_or_create(name='user')
            qs = Role.objects.all()
            return success_response([i.to_dict() for i in qs])
        except Exception as e:
            print e
            return success_response({})

    @post_action
    def role_assign_to_project_user(self, request):
        """ identity.role_assign_to_project_user(project_id, user_id, role_id)"""
        project_id, args, kwargs = self.req_parser(request)
        try:
            pid, uid, rid = args
            pur = ProjectUserRole.objects.create(project_id=pid, user_id=uid, role_id=rid)
            return success_response(pur.to_dict())
        except Exception as e:
            return error_response(str(e))


class NetworkViewSet(viewsets.ViewSet, ReqParser):
    """ip, network, subnet"""

    @post_action
    def get_ip(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            floating_ip = args[0]
            fip = Floating.objects.get(id=floating_ip)
            return success_response(fip.to_dict())
        except Exception as e:
            return error_response(str(e))

    @post_action
    def find_qos_policy(self, request):
        """qos_policy_id = qos_policy_query_ret.rules[0]['qos_policy_id']"""
        project_id, args, kwargs = self.req_parser(request)
        try:
            bandwidth = int(kwargs.get("name_or_id").split(' ')[0])
            qos_policy_id = "aaaaaaaa-aaaa-aaaa-aaaa-{}".format(str(bandwidth).zfill(12))
            data = {"rules": [{"qos_policy_id": qos_policy_id}]}
            return success_response(data)
        except Exception as e:
            return error_response(str(e))

    @post_action
    def create_ip(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            from random import randint
            floating_network_id = kwargs.get('floating_network_id')
            qos_policy_id = kwargs.get('qos_policy_id')
            fip = Floating.objects.create(floating_network_id=floating_network_id, qos_policy_id=qos_policy_id,
                                          bandwidth=int(qos_policy_id.split("-")[-1]),
                                          project_id=project_id, status="DOWN",
                                          ip='.'.join([str(randint(0, 255)) for _ in range(4)]))
            return success_response(fip.to_dict())
        except Exception as e:
            return error_response(str(e))

    @post_action
    def find_ip(self, request):
        return self.get_ip(request)

    @post_action
    def ips(self, request):
        project_id, args, kwargs = self.req_parser(request)
        qs = Floating.objects.filter(project_id=project_id)
        data = [i.to_dict() for i in qs]
        return success_response(data)

    @post_action
    def update_ip(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            floating_ip = kwargs.get('floating_ip')
            qos_policy_id = kwargs.get('qos_policy_id')
            rate_limit = kwargs.get('rate_limit')
            fip = Floating.objects.filter(id=floating_ip).filter(qos_policy_id=qos_policy_id).first()
            fip.bandwidth = rate_limit
            fip.save()
            return success_response(fip.to_dict())
        except Exception as e:
            print e
            return success_response({})

    @post_action
    def delete_ip(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            floating_ip = args[0]
            Floating.objects.filter(Q(id=floating_ip) | Q(ip=floating_ip)).delete()
            return success_response({})
        except Exception as e:
            return error_response(str(e))

    @post_action
    def find_network(self, request):
        project_id, args, kwargs = self.req_parser(request)
        q = self.first_or_none(args)
        vpc = Network.objects.filter(Q(id=q) | Q(name=q)).first()
        if vpc:
            return success_response(vpc.to_dict())
        else:
            return success_response({})

    @post_action
    def create_network(self, request):
        """network = self.conn.network.create_network(name=network_name, description=network_description)"""
        project_id, args, kwargs = self.req_parser(request)
        name = kwargs.get('name')
        description = kwargs.get('description')
        if name and description:
            vpc = Network.objects.create(name=name, cidr=description, project_id=project_id, status="ACTIVE")
            return success_response(vpc.to_dict())
        else:
            return error_response("params error :{}".format(kwargs))

    @post_action
    def networks(self, request):
        project_id, args, kwargs = self.req_parser(request)
        ext_vpc, _ = Network.objects.get_or_create(name="ext-net", cidr='10.0.0.0/24', project=Project.admin_project())
        vpcs = Network.objects.filter(project_id=project_id)
        data = [i.to_dict() for i in vpcs]
        data.append(ext_vpc.to_dict())
        return success_response(data)

    @post_action
    def update_network(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            vpc_id = args[0]
            name = kwargs.get('name')
            description = kwargs.get('description')
            vpc = Network.objects.get(id=vpc_id)
            if name or description:
                vpc.name = name
                vpc.detail = description
                vpc.save()
                return success_response(vpc.to_dict())
        except Exception as e:
            return error_response(str(e))

    @post_action
    def get_network(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            pk = self.first_or_none(args) or kwargs.get("network")
            if not pk:
                raise Exception("params error")
            vpc = Network.objects.get(pk=pk)
            return success_response(vpc.to_dict())
        except Exception as e:
            return error_response(str(e))

    @post_action
    def delete_network(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            Network.objects.filter(id=args[0]).delete()
        except Exception as e:
            print e
        return success_response({})

    @post_action
    def find_subnet(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            sub_id = args[0]
            sub = Subnet.objects.get(id=sub_id)
            return success_response(sub.to_dict())
        except Exception as e:
            print e
            return success_response({})

    @post_action
    def create_subnet(self, request):
        """'kwargs': '{"name": "default_subnet", "enable_dhcp": true, "network_id":
        "c309bae9-c792-4e67-8620-424319f03b41", "dns_nameservers": ["8.8.4.4", "114.114.114.114"], "gateway_ip":
        "172.31.4.1", "ip_version": 4, "cidr": "172.31.4.0/24"}' """
        project_id, args, kwargs = self.req_parser(request)
        name = kwargs.get('name')
        network_id = kwargs.get('network_id')
        gateway_ip = kwargs.get('gateway_ip')
        cidr = kwargs.get('cidr')
        if all([name, network_id, network_id, gateway_ip, cidr]):
            sub = Subnet.objects.create(project_id=project_id, name=name,
                                        network_id=network_id, gateway_ip=gateway_ip, cidr=cidr)
            return success_response(sub.to_dict())
        else:
            return error_response("params error:{}".format(kwargs))

    @post_action
    def update_subnet(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            sub_id = args[0]
            name = kwargs.get('name')
            description = kwargs.get('description')
            sub = Subnet.objects.get(id=sub_id)
            if name or description:
                sub.name = name
                sub.detail = description
                sub.save()
            return success_response(sub.to_dict())
        except Exception as e:
            print e
            return success_response({})

    @post_action
    def subnets(self, request):
        project_id, args, kwargs = self.req_parser(request)
        network_id = kwargs.get("network_id") or self.first_or_none(args)
        if network_id:
            subs = Subnet.objects.filter(network_id=network_id)
        else:
            subs = Subnet.objects.all()
        data = [i.to_dict() for i in subs]
        return success_response(data)

    @post_action
    def delete_subnet(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            Subnet.objects.filter(id=args[0]).delete()
        except Exception as e:
            print e
        return success_response({})

    @post_action
    def ports(self, request):
        project_id, args, kwargs = self.req_parser(request)
        ser_id = args[0]
        try:
            ports = Port.objects.get(instance_id=ser_id)
        except Exception as e:
            print e
        return success_response({})

    @post_action
    def get_router(self, request):
        """router = self.conn.network.create_router(name=name)"""
        project_id, args, kwargs = self.req_parser(request)
        rid = self.first_or_none(args)
        try:
            if not rid:
                raise Exception("params error")
            router = Router.objects.get(pk=rid)
            return success_response(router.to_dict())
        except Exception as e:
            return error_response(str(e))

    @post_action
    def create_router(self, request):
        """router = self.conn.network.create_router(name=name)"""
        project_id, args, kwargs = self.req_parser(request)
        name = kwargs.get("name")
        if not name:
            return error_response("params error:{}".format(kwargs))
        router = Router.objects.create(name=name, project_id=project_id)
        return success_response(router.to_dict())

    @post_action
    def delete_router(self, request):
        project_id, args, kwargs = self.req_parser(request)
        if not self.first_or_none(args):
            return error_response("params error:{}".format(args))
        try:
            Router.objects.get(pk=self.first_or_none(args)).delete()
            return success_response({})
        except Exception as e:
            return error_response(str(e))

    @post_action
    def update_router(self, request):
        """router = self.conn.network.update_router(router=router, external_gateway_info=external_gateway_info)"""
        project_id, args, kwargs = self.req_parser(request)
        router = kwargs.get("router")
        external_gateway_info = kwargs.get("external_gateway_info")
        if not router:
            return error_response("params error:{}".format(kwargs))
        try:
            router = Router.objects.get(pk=router)
            router.detail = json.dumps(external_gateway_info)
            router.save()
            return success_response(router.to_dict())
        except Exception as e:
            return error_response(str(e))

    @post_action
    def add_interface_to_router(self, request):
        """
        router = self.conn.network.add_interface_to_router(router=router, subnet_id=subnet_id) ret = {
        u'network_id':u'4df259d4-7b71-4b81-a746-ab97f784a04f', u'tenant_id': u'7c1d649227dd4e57abc21f75788cbe74',
        u'subnet_id': u'8df1b8ca-ef68-40a6-87e3-cedcd6507a27', u'subnet_ids': [
        u'8df1b8ca-ef68-40a6-87e3-cedcd6507a27'], u'port_id': u'27c508ff-64eb-4e12-99ff-b0581203bf7d',
        u'id': u'b5e310b1-344c-4452-aab7-667db12218ac'}
        """
        project_id, args, kwargs = self.req_parser(request)
        router = kwargs.get("router")
        subnet_id = kwargs.get("subnet_id")
        port_id = kwargs.get("port_id")
        if not router or not subnet_id:
            return error_response("params error:{}".format(kwargs))
        try:
            router = Router.objects.get(pk=router)
            subnet = Subnet.objects.get(pk=subnet_id)
            if port_id:
                port = Port.objects.get(pk=port_id)
                port.router = router
                port.save()
            else:
                port = Port.objects.create(project_id=project_id, network=subnet.network, subnet=subnet, router=router,
                                           ip=subnet.assign_fixed_ip())
            ret = {
                "network_id": subnet.network.pk,
                "tenant_id": project_id,
                "subnet_id": subnet_id,
                "subnet_ids": [subnet_id],
                "port_id": port.pk,
                "id": router.pk
            }
            return success_response(ret)
        except Exception as e:
            return error_response(str(e))

    @post_action
    def get_security_group(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            sg_id = args[0]
            sg = SCGroup.objects.get(id=sg_id)
            return success_response(sg.to_dict())
        except Exception as e:
            return error_response(str(e))

    @post_action
    def create_security_group(self, request):
        project_id, args, kwargs = self.req_parser(request)
        name = kwargs.get('name')
        description = kwargs.get('description')
        if name or description:
            sg = SCGroup.objects.create(name=name, detail=description, project_id=project_id)
            return success_response(sg.to_dict())
        else:
            return error_response("params error")

    @post_action
    def security_groups(self, request):
        project_id, args, kwargs = self.req_parser(request)
        sgs = SCGroup.objects.filter(project_id=project_id)
        data = [i.to_dict() for i in sgs]
        return success_response(data)

    @post_action
    def update_security_group(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            sg_id = args[0]
            name = kwargs.get('name')
            description = kwargs.get('description')
            sg = SCGroup.objects.get(id=sg_id)
            if name or description:
                sg.name = name
                sg.detail = description
                sg.save()
            return success_response(sg.to_dict())
        except Exception as e:
            return error_response(str(e))

    @post_action
    def delete_security_group(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            SCGroup.objects.filter(id=args[0]).delete()
        except Exception as e:
            print e
        return success_response({})

    @post_action
    def get_security_group_rule(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            sgr_id = args[0]
            sgr = SCGroupRule.objects.get(id=sgr_id)
            return success_response(sgr.to_dict())
        except Exception as e:
            print e
            return success_response({})

    @post_action
    def create_security_group_rule(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            detail = json.dumps(kwargs)
            sgr = SCGroupRule.objects.create(project_id=project_id, sc_group_id=kwargs.get('security_group_id'),
                                             detail=detail)
            return success_response(sgr.to_dict())
        except Exception as e:
            return error_response(str(e))

    @post_action
    def security_group_rules(self, request):
        project_id, args, kwargs = self.req_parser(request)
        sc_qs = SCGroupRule.objects.filter(project_id=project_id)
        data = [i.to_dict() for i in sc_qs]
        return success_response(data)

    @post_action
    def delete_security_group_rule(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            id = args[0]
            SCGroupRule.objects.filter(id=id).delete()
            return success_response({})
        except Exception as e:
            return error_response(str(e))


class ImageViewSet(viewsets.ViewSet, ReqParser):
    """image"""

    @post_action
    def images(self, request):
        project_id, args, kwargs = self.req_parser(request)
        if kwargs.get("visibility") == "private":
            qs = Image.objects.filter(public=False, project_id=project_id)
        else:
            qs = Image.objects.filter(public=True)
        return success_response([i.to_dict() for i in qs])

    @post_action
    def get_image(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            img_id = self.first_or_none(args)
            img = Image.objects.get(id=img_id)
            return success_response(img.to_dict())
        except Exception as e:
            return error_response(str(e))

    @post_action
    def delete_image(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            img_id = args[0]
            Image.objects.filter(id=img_id).delete()
        except Exception as e:
            print e
        return success_response({})


class ComputeViewSet(viewsets.ViewSet, ReqParser):
    """compute
    servers = conn.compute.servers()
    server = conn.compute.find_server(name_or_id)
    server = conn.compute.create_server(**kwargs)
    server = conn.compute.update_server(server=server_id, name=name)
    server = conn.compute.stop_server(server_id)
    server = conn.compute.start_server(server_id)
    server = conn.compute.reboot_server(server_id)
    server = conn.compute.delete_server(server_id)
    """

    @post_action
    def servers(self, request):
        """
         conn.compute.servers()
        """
        project_id, args, kwargs = self.req_parser(request)
        servers = Instance.objects.filter(project_id=project_id)
        data = [i.to_dict() for i in servers]
        return success_response(data)

    @post_action
    def get_server(self, request):
        """
        server = conn.compute.find_server(id)
        """
        project_id, args, kwargs = self.req_parser(request)
        try:
            if args:
                server = Instance.objects.filter(Q(id=args[0]) | Q(name=args[0])).first()
                return success_response(server.to_dict())
            else:
                return success_response({})
        except Exception as e:
            return error_response(str(e))

    @post_action
    def server_interfaces(self, request):
        """
         server = conn.compute.server_interfaces(server_id)
        """
        return success_response({})

    @post_action
    def find_server(self, request):
        return self.get_server(request)

    @post_action
    def create_server(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            network_id = kwargs["networks"][0]["uuid"]
            subnet = Subnet.objects.filter(network_id=network_id).first()
            port = subnet.port_set.filter(instance=None).first()
            if not port:
                port = Port.objects.create(project_id=project_id, network=subnet.network, subnet=subnet,
                                           ip=subnet.assign_fixed_ip())
            create_instance_dict = {
                "project_id": project_id,
                "name": kwargs["name"],
                "image_id": kwargs["image_id"],
                "flavor_id": kwargs["flavor_id"],
                "network_id": network_id,
                "fixed_ip": port.ip,
                "subnet": subnet,
                "status": "ACTIVE",
                "security_group_id": SCGroup.objects.filter(project_id=project_id).first().pk
            }
            instance = Instance.objects.create(**create_instance_dict)
            Volume.objects.create(instance=instance, is_bootable=True, attached_at=timezone.now(),
                                  status='IN-USE', project_id=project_id)
            port.instance = instance
            port.save()
            return success_response(instance.to_dict())
        except Exception as e:
            return error_response(str(e))

    @post_action
    def start_server(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            sid = self.first_or_none(args)
            srv = Instance.objects.get(pk=sid)
            srv.status = "ACTIVE"
            srv.save()
            return success_response(srv.to_dict())
        except Exception as e:
            return error_response(str(e))

    @post_action
    def stop_server(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            sid = self.first_or_none(args)
            srv = Instance.objects.get(pk=sid)
            srv.status = "SHUTOFF"
            srv.save()
            return success_response(srv.to_dict())
        except Exception as e:
            return error_response(str(e))

    @post_action
    def confirm_server_resize(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            sid = self.first_or_none(args)
            srv = Instance.objects.get(pk=sid)
            srv.status = "SHUTOFF"
            srv.save()
            return success_response(srv.to_dict())
        except Exception as e:
            return error_response(str(e))

    @post_action
    def reboot_server(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            sid = self.first_or_none(args)
            srv = Instance.objects.get(pk=sid)
            srv.status = "ACTIVE"
            srv.save()
            return success_response(srv.to_dict())
        except Exception as e:
            return error_response(str(e))

    @post_action
    def resize_server(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            sid, flavor_id = args
            srv = Instance.objects.get(pk=sid)
            srv.flavor_id = flavor_id
            srv.status = "VERIFY_RESIZE"
            srv.save()
            return success_response(srv.to_dict())
        except Exception as e:
            return error_response(str(e))

    @post_action
    def delete_server(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            pk = self.first_or_none(args)
            Instance.objects.get(pk=pk).delete()
            return success_response({})
        except Exception as e:
            return error_response(str(e))

    @post_action
    def attach_volume_to_server(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            sid, vid = args[0], args[1]
            srv = Instance.objects.get(pk=sid)
            vol = Volume.objects.get(pk=vid)
            vol.instance = srv
            vol.status = "IN-USE"
            vol.save()
            return success_response(srv.to_dict())
        except Exception as e:
            return error_response(str(e))

    @post_action
    def detach_volume_from_server(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            sid, vid = args
            vol = Volume.objects.get(pk=vid)
            vol.instance = None
            vol.status = "AVAILABLE"
            vol.save()
            return success_response({})
        except Exception as e:
            return error_response(str(e))

    @post_action
    def find_flavor(self, request):
        project_id, args, kwargs = self.req_parser(request)
        qid = self.first_or_none(args)
        flavor = Flavor.objects.filter(Q(name=qid) | Q(pk=qid)).first()
        if flavor:
            return success_response(flavor.to_dict())
        else:
            return success_response({})

    @post_action
    def flavors(self, request):
        qs = Flavor.objects.all()
        return success_response([i.to_dict() for i in qs])

    @post_action
    def create_flavor(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            vcpus = kwargs["vcpus"]
            ram = kwargs["ram"]
            name = kwargs["name"]
        except KeyError:
            return error_response("params error:{}".format(kwargs))
        flavor = Flavor.objects.create(vcpus=vcpus, ram=ram, name=name)
        return success_response(flavor.to_dict())

    @post_action
    def add_floating_ip_to_server(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            server_id = args[0]  # floating_ip
            floating_ip = args[1]  # floating_ip
            fixed_address = kwargs.get('fixed_address') # instance的内网ip
            srv = Instance.objects.get(id=server_id)
            fip = Floating.objects.get(Q(ip=floating_ip) | Q(id=floating_ip))
            srv.floating = fip
            srv.public_ip = floating_ip
            srv.addresses_updated = False
            srv.floating_id = fip.id
            fip.fixed_ip_address = fixed_address # 更新instance内网地址到floating
            fip.status = 'ACTIVE'
            fip.save()
            srv.save()
            return success_response(srv.to_dict())
        except Exception as e:
            return error_response(str(e))

    @post_action
    def remove_floating_ip_from_server(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            server_id = args[0]
            floating_ip = args[1]
            srv = Instance.objects.get(id=server_id)
            fip = Floating.objects.get(ip=floating_ip)
            srv.floating = None
            srv.public_ip = None
            srv.addresses_updated = False
            fip.fixed_ip_address = None
            fip.status = 'DOWN'
            fip.save()
            srv.save()
            return success_response(srv.to_dict())
        except Exception as e:
            return error_response(str(e))


class BlockStoreViewSet(viewsets.ViewSet, ReqParser):
    """block_store"""

    @post_action
    def get_volume(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            obj = Volume.objects.get(id=self.first_or_none(args))
            return success_response(obj.to_dict())
        except Exception as e:
            return error_response(str(e))

    @post_action
    def create_volume(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            name = kwargs.get("name")
            size = kwargs.get("size")
            volume_type = kwargs.get("volume_type")
            obj = Volume.objects.create(project_id=project_id, name=name, size=size, volume_type=volume_type,
                                        status="AVAILABLE")
            return success_response(obj.to_dict())
        except Exception as e:
            return error_response(str(e))

    @post_action
    def volumes(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            qs = Volume.objects.get(project_id=project_id)
            return success_response([i.to_dict() for i in qs])
        except Exception as e:
            return error_response(str(e))

    @post_action
    def upload_volume_image(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            vol_id, image_name = args
            volume = Volume.objects.get(pk=vol_id)
            img = Image.objects.create(name=image_name, volume_id=vol_id, size=volume.size, project_id=project_id)
            return success_response(img.to_dict())
        except Exception as e:
            return error_response(str(e))

    @post_action
    def extend_volume(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            volume_id = args[0]
            new_size = int(args[1])
            volume = Volume.objects.get(id=volume_id)
            volume.size = new_size
            volume.save()
            return success_response(volume.to_dict())
        except Exception as e:
            return error_response(str(e))

    @post_action
    def update_volume(self, request):
        project_id, args, kwargs = self.req_parser(request)
        volume_id = args[0]
        name = kwargs.get('name')
        description = kwargs.get('description')
        try:
            volume = Volume.objects.get(id=volume_id)
            if name or description:
                volume.name = name
                volume.detail = description
                volume.save()
            return success_response(volume.to_dict())
        except Exception as e:
            return error_response(str(e))

    @post_action
    def delete_volume(self, request):
        project_id, args, kwargs = self.req_parser(request)
        try:
            volume_id = args[0]
            Volume.objects.filter(id=volume_id).delete()
            return success_response({})
        except Exception as e:
            return error_response(str(e))
