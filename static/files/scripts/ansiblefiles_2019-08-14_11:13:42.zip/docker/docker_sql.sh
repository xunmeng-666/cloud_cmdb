#!/usr/bin/env bash

export registry=10.211.55.102:5555
dirs=$(pwd)

installrpm() {
    echo "安装JQ"
    which jq
    if [ $? -ne 0 ];then
        which wget
        if [ $? -ne 0 ];then
            yum install wget -y
        fi
        wget http://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
        rpm -ivh epel-release-latest-7.noarch.rpm
        yum install -y jq
    fi
}


installdocker() {
    which docker
    if [ $? -ne 0 ]; then
        echo "未找到docker，开始安装"
        yum install -y docker docker-client docker-common
        echo "安装完成，启动服务"
        systemctl restart docker
        systemctl enable docker
        installdocker
    else
        echo "docker 已安装"
    fi
}

compose() {
    which docker-compose
    if [ $? -ne 0 ]; then
        echo"未找到docker-compose，开始安装"
        sudo curl -L "https://github.com/docker/compose/releases/download/1.24.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
        chmod +x /usr/local/bin/docker-compose
    else
        echo " 已安装docker-compose"
    fi
}

dockerregistry() {
    echo "设置Docker仓库"
    echo {'"'insecure-registries'"':['"'$registry'"']} > /etc/docker/daemon.json
    echo "设置完成\n重启docker服务"
    systemctl daemon-reload
    systemctl stop docker
    if [ $? -eq 0 ];then
        echo "服务停止成功"
    else
        echo "\033[35m 服务停止失败\033[0m"
        systemctl status docker
    fi
    systemctl start docker
    if [ $? -eq 0 ];then
        echo "服务启动成功"
    else
        echo "\033[35m 服务启动失败\033[0m"
        systemctl status docker
    fi
}

container() {
    echo "set env of docker registry"
    ver=`curl "http://$registry/v2/centos7-msghandler/tags/list" | jq '.tags[-1]'`
    msghandler_version=${ver:1:8}
    ver=`curl "$registry/v2/ecs_all/tags/list" | jq '.tags[-1]'`
    ecs_version=${ver:1:8}
    ver=`curl "http://$registry/v2/centos7-cloudaio-admin/tags/list" | jq '.tags[-1]'`
    admin_version=${ver:1:8}
    ver=`curl "http://$registry/v2/centos7-cloudaio-console-vip/tags/list" | jq '.tags[-1]'`
    vip_version=${ver:1:8}
    export vip=$registry/centos7-cloudaio-console-vip:${vip_version}
    export admin=$registry/centos7-cloudaio-admin:${admin_version}
    export ecs_all=$registry/ecs_all:${ecs_version}
    export msghandler=$registry/centos7-msghandler:${msghandler_version}
    ipaddr=$(ip addr | awk '/^[0-9]+: / {}; /inet.*global/ {print gensub(/(.*)\/(.*)/, "\\1", "g", $2)}')
    export API_ADDRESS=$(hostname -i |awk '{print $1}')
}

runcompose() {
    echo " run docker-compose "
    ls -al
    cd $dirs
    docker-compose up -d
    docker ps
}


script() {
    echo "run command on docker container"
    CONTAIN_NAME=ecs_cloud
    sudo docker exec $CONTAIN_NAME bash -c "mkdir -p /var/log/ecscloud;\
    chown -R ecscloud:ecscloud /var/log/ecscloud;\
    chmod a+x -R /var/www/ecscloud_web/.venv;\
    chown -R ecscloud:ecscloud /var/log/ecscloud;\
    chgrp -R ecscloud /var/log/ecscloud"


    sudo docker exec $CONTAIN_NAME bash -c "systemctl start ntpd.service"
    sudo docker exec $CONTAIN_NAME bash -c "systemctl start sshd.service"
    docker exec os_mock bash -c "python /var/www/os_mock/manage.py makemigrations;python /var/www/os_mock/manage.py migrate"

    docker exec $CONTAIN_NAME bash -c "sh /var/www/ecscloud_web/resall.sh"
    docker exec ecs_cloud bash -c "source /var/www/ecscloud_web/.venv/bin/activate; \
                                python /var/www/ecscloud_web/manage.py makemigrations"
    docker exec ecs_cloud bash -c "source /var/www/ecscloud_web/.venv/bin/activate; \
                                python /var/www/ecscloud_web/manage.py migrate_settings"
    docker exec ecs_cloud bash -c "source /var/www/ecscloud_web/.venv/bin/activate; \
                                python /var/www/ecscloud_web/manage.py migrate --database default"
    docker exec cloudaio-admin bash -c "cd /opt/cloudaio-admin/script/; /bin/bash ./update_database.sh"
    docker exec cloudaio-console-vip bash -c "cd /opt/cloudaio-console-vip/script/; /bin/bash ./update_database.sh"


}

installrpm
installdocker
compose
dockerregistry
container
runcompose
script