# -*- coding:utf-8 -*-


import os
STACK = 'VIP'

# 工单接口地址
WORK_URL = os.environ.get('WORK_URL')
WORK_ORDER_SYSTEM_URL = "http://{{hostvars[groups['admin_master'] | join()].ansible_ssh_host}}:12080"
CLOUD_HIGH_URL = "http://172.18.141.32:8181"

LOGIN_FROM_CAS = False
LOGOUT_REDIRECT_URL = '/'
# uam settings, is valid only when LOGIN_FROM_CAS is true
CAS_SERVER_URL = 'http://10.0.38.147:16080/cas/'
CAS_REDIRECT_URL = '/console/index/'
CAS_VERSION='3'


CTYUN_HOST = "192.168.13.180"
CTYUN_API_URL = "192.168.13.180"
CTYUN_INTERFACE_HOST = "192.168.13.47"
CTYUN_PAY_URL ="http://%s/order/order_detail"%CTYUN_HOST
CTYUN_API_AK = "458255a82af6430fbbdbefc8c1cfae1e"
CTYUN_API_SK = "aebf38e1f1164633b7cfec5bd8ee9c5c"
#CTYUN_API_AK = "6bb738a3082247ccb466b57ecbab11c5"
#CTYUN_API_SK = "06cefff622234e60a068e422c7ef9b21"
SERVICE_TAG = "OVMS"
PAAS_SERVICE_TAG = "PAAS"

# Ctyun 用户详情接口
USEE_INFO_URL = "http://192.168.13.122:81/account/QueryAccountInfo"
TITLE = "VIP"

# admin 用户详情接口
ADMIN_URL = os.environ.get('ADMIN_URL')
CLOUDAIO_ADMIN_URL = "http://{{hostvars[groups['admin_master'] | join()].ansible_ssh_host}}:8081/"
CLOUDAIO_ADMIN_API_AK = '1c00d81ef5a211e7b82f186590d96509'
CLOUDAIO_ADMIN_API_SK = 'ddb625423707f651ee45c0d8f1ecb1a56ba9118c'

# 数据库配置


DATABASES = {
    'default': {
        'NAME': 'yj_vip',
        'ENGINE': 'django.db.backends.mysql',  # or use mysql.connector.django
        'USER': 'test',
        'PASSWORD': 'test123',
        'HOST': "{{hostvars[groups['mysql_master'] | join()].ansible_ssh_host}}",
        'PORT': '3306',
        'OPTIONS':{
            'init_command': "SET sql_mode='STRICT_TRANS_TABLES'",
        }
    },
}



ROOT_PATH = os.path.dirname(os.path.abspath(__file__))

ROOT_URLCONF = 'console.urls'
WEBROOT = '/'
STATIC_ROOT = os.path.abspath(os.path.join(ROOT_PATH, 'static'))
STATIC_URL = WEBROOT + 'static/'

INSTALLED_APPS = (
    'django.contrib.contenttypes',
    'django.contrib.auth',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'console',

    'django_cas_ng',
)

apps = ('console',)

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [ROOT_PATH+"/templates", ROOT_PATH+"/static",],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.i18n',
                'django.template.context_processors.request',
                'django.template.context_processors.media',
                'django.template.context_processors.static',
                'django.contrib.messages.context_processors.messages',
                'django.contrib.auth.context_processors.auth',
            ],
        },
    },
]

MIDDLEWARE_CLASSES = (
    'django.middleware.cache.UpdateCacheMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.auth.middleware.SessionAuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'django.middleware.cache.FetchFromCacheMiddleware',
    'django_cas_ng.middleware.CASMiddleware',
    'console.middleware.base.LoggingMiddleware'
)

SECRET_KEY = '*lk^6@0l0(iulgar$j)faff&^(^u+qk3j73d18@&+ur^xuTxY'

DEBUG = True

ALLOWED_HOSTS = ['*',]

AUTHENTICATION_BACKENDS = (
    'console.backends.CtyunAdminModelBackend',
)

if LOGIN_FROM_CAS:
    CAS_BACKEND = ('console.backends.UAMCASBackend',)
    AUTHENTICATION_BACKENDS = CAS_BACKEND

AUTH_USER_MODEL = 'console.User'

USE_TZ = True
TIME_ZONE = "UTC"

# session setting
SESSION_ENGINE = 'django.contrib.sessions.backends.signed_cookies'
SESSION_COOKIE_HTTPONLY = True
SESSION_EXPIRE_AT_BROWSER_CLOSE = True
SESSION_COOKIE_SECURE = False

SESSION_COOKIE_AGE = 1800

SESSION_TIMEOUT = 1800

SESSION_SERIALIZER = 'django.contrib.sessions.serializers.PickleSerializer'

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'standard': {
            'format': '[%(asctime)s] %(levelname)s %(pathname)s %(lineno)d: %(message)s'
        },
        'request': {
            'format': '[%(asctime)s] %(levelname)s: %(message)s'
        }
    },
    'handlers': {
        'stream':{
            'level': 'DEBUG',
            'class': 'logging.StreamHandler',
            'formatter': 'standard'
        },
        'console': {
            'level': 'DEBUG',
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': '/var/log/console.log',
            'maxBytes': 1024*1024*10,  # 10 MB
            'backupCount': 10,
            'formatter':'standard'
        },
        'console-access': {
            'level': 'DEBUG',
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': '/var/log/console-access.log',
            'maxBytes': 1024*1024*10,  # 10 MB
            'backupCount': 10,
            'formatter': 'request'
        },
        'console-error': {
            'level': 'ERROR',
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': '/var/log/console-error.log',
            'maxBytes': 1024*1024*10,  # 10 MB
            'backupCount': 10,
            'formatter': 'standard'
        }
    },
    'loggers': {
        'console': {
            'handlers': ['console', 'stream'],
            'level': 'DEBUG',
            'propagate': True,
        },
        'console-access': {
            'handlers': ['console-access'],
            'level': 'DEBUG',
            'propagate': False,
        },
        'console-error': {
            'handlers': ['console-error', 'console'],
            'level': 'ERROR',
            'propagate': False,
        },
    },
}

# cloudstack api config
CLOUDSTACK_API_DEBUGGING = False
CLOUDSTACK_API_VERBOSE = True
